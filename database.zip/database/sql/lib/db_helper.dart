// ignore_for_file: non_constant_identifier_names

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:sql/Note.dart';

class DbHelper {
  Database? _database;
  String tablename = "notes";

  Future<Database> get database async {
    if (_database != null) {
      return _database!;
    } else {
      _database = await initDb();
      return _database!;
    }
  }

  Future<Database> initDb() async {
    final dbpath = await getDatabasesPath();
    final note_db_path = join(dbpath, "notes.db");

    return await openDatabase(
      note_db_path,
      version: 1,
      onCreate: (db, Version) {
        db.execute(
            "CREATE TABLE $tablename(id INTEGER KEY, title TEXT, content TEXT)");
      },
    );
  }

  insert(Note note) async {
    final db = await database;
    await db.insert(
      tablename,
      note.toMap(),
    );
  }

  update(Note note) async {
    final db = await database;
    await db
        .update(tablename, note.toMap(), where: 'id =?', whereArgs: [note.id]);
  }

  delete(int id) async {
    final db = await database;
    await db.delete(tablename, where: "id =? ", whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> queryAll() async {
    final db = await database;
    return await db.query(tablename);
  }
}
