class Students {
  int? id;
  String rollno;
  String name;
  Students({this.id, required this.rollno, required this.name});
}
