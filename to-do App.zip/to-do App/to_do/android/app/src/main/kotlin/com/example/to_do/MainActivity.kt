package com.example.to_do

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
