class todo {
  String title;
  bool isDone;
  String subt;
  todo({required this.title, required this.isDone, required this.subt});
}
