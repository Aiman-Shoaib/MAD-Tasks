import 'package:flutter/material.dart';
import 'package:to_do/Models/todo.dart';

// ignore: camel_case_types
class todonotifier with ChangeNotifier {
  List<todo> todolist = [];
  List<todo> get gettodos => todolist;
  addTodos(todo todo) {
    todolist.add(todo);
    notifyListeners();
  }

  removeTodo(int index) {
    todolist.removeAt(index);
    notifyListeners();
  }

  toggleisDone(int index) {
    todolist[index].isDone = !todolist[index].isDone;
    notifyListeners();
  }
}
