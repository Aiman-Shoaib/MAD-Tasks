import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:to_do/Models/todo.dart';
import 'package:to_do/todo_notifier.dart';

void main() {
  runApp(
    MultiProvider(providers: [
      ChangeNotifierProvider(
        create: (BuildContext context) {
          return todonotifier();
        },
      )
    ], child: const MyApp()),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  TextEditingController t = TextEditingController();
  TextEditingController st = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('To Do List'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: ListView.builder(
          itemCount: context.watch<todonotifier>().gettodos.length,
          itemBuilder: (context, index) {
            todo todoo = context.watch<todonotifier>().gettodos[index];
            return ListTile(
              leading: Checkbox(
                  value: todoo.isDone,
                  onChanged: (value) {
                    context.read<todonotifier>().toggleisDone(index);
                  }),
              title: Text(todoo.title),
              subtitle: Text(todoo.subt),
              trailing: IconButton(
                onPressed: () {
                  context.read<todonotifier>().removeTodo(index);
                },
                icon: const Icon(Icons.delete),
              ),
            );
          }),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          showDialog(
              context: context,
              builder: (BuildContext context) {
                return SimpleDialog(
                  title: const Text("Add todos"),
                  contentPadding: const EdgeInsets.all(16.0),
                  children: [
                    TextFormField(
                      controller: t,
                      decoration:
                          const InputDecoration(label: Text("Enter title")),
                    ),
                    TextFormField(
                      controller: st,
                      decoration: const InputDecoration(
                          label: Text("Enter Description")),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    ElevatedButton(
                        onPressed: () {
                          context.read<todonotifier>().addTodos(todo(
                              title: t.text, subt: st.text, isDone: false));
                          st.clear();
                          t.clear();
                        },
                        child: const Text("Add"))
                  ],
                );
              });
        },
      ),
    );
  }
}
