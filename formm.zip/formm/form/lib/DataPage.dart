 // ignore: file_names
import 'package:flutter/material.dart';
import 'package:form/main.dart';

class DataPage extends StatefulWidget {
  const DataPage({super.key});

  @override
  State<DataPage> createState() => _DataPageState();
}

class _DataPageState extends State<DataPage> {
  @override
  Widget build(BuildContext context) {
    final FormData formData =
        ModalRoute.of(context)!.settings.arguments as FormData;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("Signup Data"),
      ),
      body: Column(
        children: [
          Text("Username: ${formData.name}"),
          Text("Email: ${formData.email}"),
          Text("Gender: ${formData.Gender}"),
          Text("Date of Birth: ${formData.dob}"),
        ],
      ),
    );
  }
}
