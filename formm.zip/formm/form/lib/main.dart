import 'package:flutter/material.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'package:form/DataPage.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(const MyApp());
}

class FormData {
  final String name;
  final String email;
  // ignore: non_constant_identifier_names
  final String Gender;
  String dob;

  FormData(
      {required this.name,
      required this.email,
      // ignore: non_constant_identifier_names
      required this.Gender,
      required this.dob});
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      initialRoute: "/signpage",
      routes: {
        "/signpage": (context) => const MyHomePage(),
        "/datapage": (context) => const DataPage(),
      },
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<StatefulWidget> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  GlobalKey<FormState> formkey = GlobalKey<FormState>();
  TextEditingController ucontroller = TextEditingController();
  TextEditingController pcontroller = TextEditingController();
  TextEditingController econtroller = TextEditingController();
  TextEditingController gcontroller = TextEditingController();
  TextEditingController dcontroller = TextEditingController();
  String? gender;
  bool male = false, female = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Form"),
      ),
      body: Form(
        key: formkey,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              TextFormField(
                controller: ucontroller,
                decoration: const InputDecoration(
                  labelText: "username",
                  border: UnderlineInputBorder(),
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return "please enter some value";
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: econtroller,
                decoration: const InputDecoration(
                  labelText: "Email",
                  border: UnderlineInputBorder(),
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return "please enter some value";
                  }

                  return null;
                },
              ),
              TextFormField(
                controller: pcontroller,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: "Password",
                  border: UnderlineInputBorder(),
                ),
                validator: (value) {
                  if (value!.length < 8) {
                    return "please enter 8 characters";
                  }
                  RegExp passwordRegex = RegExp(
                      r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#$%^&*]).{8,}$');
                  if (!passwordRegex.hasMatch(value)) {
                    return 'Password must contain at least one uppercase letter,\n one lowercase letter,\n one numerical digit,\n and one special character.';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: dcontroller,
                decoration: const InputDecoration(
                  labelText: 'select DOB',
                  hintText: 'dd-MM-yyyy',
                ),
                onTap: () {
                  DatePicker.showDatePicker(
                    context,
                    showTitleActions: true,
                    minTime: DateTime(1990),
                    maxTime: DateTime.now(),
                    onConfirm: (date) {
                      setState(() {
                        dcontroller.text =
                            DateFormat('dd-MM-yyyy').format(date);
                      });
                    },
                    currentTime: DateTime.now(),
                  );
                },
              ),
              Row(
                children: [
                  const Text("Select gender: "),
                  const SizedBox(width: 19),
                  const Text("Male"),
                  Radio(
                    value: "Male",
                    groupValue: gender,
                    onChanged: (value) {
                      setState(() {
                        gender = value!;
                        gcontroller.text = value;
                      });
                    },
                  ),
                  const Text("Female"),
                  Radio(
                    value: "Female",
                    groupValue: gender,
                    onChanged: (value) {
                      setState(() {
                        gender = value!;
                        gcontroller.text = value;
                      });
                    },
                  ),
                ],
              ),
              ElevatedButton(
                child: const Text("Register"),
                onPressed: () {
                  
                  if (formkey.currentState!.validate()) {
                    FormData formData = FormData(
                        name: ucontroller.text,
                        email: econtroller.text,
                        Gender: gcontroller.text,
                        dob: dcontroller.text);
                    Navigator.pushNamed(context, '/datapage',
                        arguments: formData);
                  }
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
