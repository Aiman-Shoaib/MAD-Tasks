package com.example.gesture

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
