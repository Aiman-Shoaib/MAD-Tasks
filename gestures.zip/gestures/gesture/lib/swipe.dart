import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: PictureSwipeApp(),
    );
  }
}

class PictureSwipeApp extends StatefulWidget {
  @override
  _PictureSwipeAppState createState() => _PictureSwipeAppState();
}

class _PictureSwipeAppState extends State<PictureSwipeApp> {
  int currentIndex = 0;
  List<String> images = [
    'assets/images/pin.png',
    'assets/images/gallery.jpg',
    'assets/images/img.png',
  ];
  Offset offset = const Offset(0.0, 0.0); // ffor drag gesture
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Picture Swipe App'),
      ),
      body: GestureDetector(
          onHorizontalDragEnd: (details) {
            // Determine the direction of the swipe
            if (details.primaryVelocity! < 0) {
              // Swipe left (next picture)
              setState(() {
                if (currentIndex < images.length - 1) {
                  currentIndex++;
                }
              });
            } else if (details.primaryVelocity! > 0) {
              // Swipe right (previous picture)
              setState(() {
                if (currentIndex > 0) {
                  currentIndex--;
                }
              });
            }
          },
          onPanUpdate: (details) {
            //drag
            setState(() {
              offset = Offset(
                  offset.dx + details.delta.dx, offset.dy + details.delta.dy);
            });
          }, //drag
          child: Transform.translate(
            offset: offset,
            child: PageView.builder(
              itemCount: images.length,
              controller: PageController(initialPage: currentIndex),
              itemBuilder: (context, index) {
                return Image.asset(
                  images[index],
                  width: 300,
                  height: 300,
                );
              },
            ),
          )),
    );
  }
}
